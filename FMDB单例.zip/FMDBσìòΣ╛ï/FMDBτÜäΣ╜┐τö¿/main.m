//
//  main.m
//  FMDB的使用
//
//  Created by 李自杨 on 17/2/13.
//  Copyright © 2017年 View. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
