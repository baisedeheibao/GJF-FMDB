//
//  DBDataBaseManager.m
//  FMDB的使用
//
//  Created by 李自杨 on 17/2/20.
//  Copyright © 2017年 View. All rights reserved.
//

#import "DBDataBaseManager.h"
#import "Preson.h"
static DBDataBaseManager *manager = nil;

@implementation DBDataBaseManager

+(DBDataBaseManager *)sharedDBDataBaseManager{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^{
        
        manager = [[DBDataBaseManager alloc]init];
        //创建数据库
        [manager createDataBase];

    });
    return manager;
}

-(void)createDataBase{
    //存储路径
    NSString *documents = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    NSString *path = [documents stringByAppendingPathComponent:@"haqu.db"];
    
    NSLog(@"数据库存储路径:%@",path);
    //创建数据库
    _db = [FMDatabase databaseWithPath:path];
    
}

-(void)createTable:(NSString *)tableName{
    
    [_db open];
    
    NSString *str = [NSString stringWithFormat:@"create table if not exists %@(name text, number text)",tableName];
    
//    BOOL success = [_db executeUpdate:@"create table if not exists Preson(id integer PRIMARY KEY AUTOINCREMENT, name text, number text)"];
    BOOL success = [_db executeUpdate:str];
    if (success) {
        NSLog(@"-----建表成功-----");
    }else{
        NSLog(@"-----建表失败-----");
    }
    
    [_db close];
}

//增
-(void)addDBDataBaseManager:(NSString *)tableName andModel:(Preson *)preson{
    
    [_db open];
    //        NSData *data = UIImagePNGRepresentation();
    NSString *str = [NSString stringWithFormat:@"insert into %@ (name,number) values(?,?)",tableName];
    
//    BOOL success = [self.db executeUpdate:@"insert into Preson (name,number) values(?,?)",preson.name,preson.number];
    BOOL success = [self.db executeUpdate:str,preson.name,preson.number];
    
    if (success == NO) {
        NSLog(@"---插入数据失败---");
    }else{
        NSLog(@"---插入数据成功---");
    }
    
    [_db close];
    
}

//单个删除
-(void)deleteOneDBDataBaseManager:(NSString *)tableName andModel:(Preson *)preson{
    
    [_db open];
    
    NSString *str = [NSString stringWithFormat:@"delete from %@ where name = ?",tableName];
    
//    BOOL success = [_db executeUpdate:@"delete from Preson where name=?", preson.name];
    
    BOOL success = [_db executeUpdate:str,preson.name];
    
    if (success == NO) {
        NSLog(@"---数据库单个删除失败---");
    }else{
        NSLog(@"---数据库单个删除成功---");
    }
    
    [_db close];
    
}

//全部删除
-(void)deleteAllDBDataBaseManager:(NSString *)tableName{
    
    [_db open];
    NSString *str = [NSString stringWithFormat:@"delete from %@",tableName];
    
//    BOOL success = [_db executeUpdate:@"delete from preson"];
    BOOL success = [_db executeUpdate:str];
    
    if (success == NO) {
        NSLog(@"---数据库全部删除失败---");
    }else{
        NSLog(@"---数据库全部删除成功---");
    }
    [_db close];
}

//修改
-(void)alterDBDataBaseManager:(NSString *)tableName andModel:(Preson *)preson{
    
    [_db open];
    //修改所有的name
    //    BOOL success = [_db executeUpdate:@"update Preson set name=?",_nameTextField.text];
    //修改所有的number
    //    BOOL success = [_db executeUpdate:@"update Preson set number=?",_numberTextField.text];
    //根据姓名修改电话号码
    //    BOOL success = [_db executeUpdate:@"update Preson set number =? where name = ?",preson.name,preson.number];
    
    //根据姓名修改电话号码
    NSString *str = [NSString stringWithFormat:@"update %@ set number = ? where name = ?",tableName];
    
    BOOL success = [_db executeUpdate:str,preson.number,preson.name];
    
    if (success == NO) {
        NSLog(@"---修改失败---");
    }else{
        NSLog(@"---修改成功---");
    }
    
    [_db close];
    
}

//查看单个
-(Preson *)checkOneDBDataBaseManager:(NSString *)tableName andName:(NSString *)name{
    
    [_db open];
    
    Preson *pre = [[Preson alloc]init];
    
    NSString *str = [NSString stringWithFormat:@"select * from %@ where name = ?",tableName];
    
//    FMResultSet *set = [_db executeQuery:@"select * from Preson where name=?",name];
    
    FMResultSet *set = [_db executeQuery:str,name];
    
    while ([set next]) {
        
        pre.name = [set stringForColumn:@"name"];
        pre.number = [set stringForColumn:@"number"];
        
    }
    
    [_db close];
    
    return pre;
    
}

//查看全部
-(NSMutableArray *)checkAllDBDataBaseManager:(NSString *)tableName{
    
    [_db open];
    
    NSMutableArray *dataArray = [NSMutableArray array];
    
    NSString *str = [NSString stringWithFormat:@"select * from %@",tableName];
    
//    FMResultSet *set = [_db executeQuery:@"select * from Preson"];
    
    FMResultSet *set = [_db executeQuery:str];
    
    while ([set next]) {
        
        Preson *preson = [[Preson alloc]init];
        
        preson.name = [set stringForColumn:@"name"];
        preson.number = [set stringForColumn:@"number"];
        
        [dataArray addObject:preson];
        
    }
    [_db close];
    
    return dataArray;
    
}

@end
